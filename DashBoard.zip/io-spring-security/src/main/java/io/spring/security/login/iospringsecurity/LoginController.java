package io.spring.security.login.iospringsecurity;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.servlet.http.HttpServletResponse;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Controller;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

	@GetMapping("/login")
	public String login() {

		return "login.html";
	}

	@GetMapping("/display")
	public void welcome(HttpServletResponse response) throws IOException {
		response.setContentType("application/pdf");
		StreamUtils.copy(new FileSystemResource("C:\\Users\\ankit.kumarsingh\\Downloads\\Monthly AMRC  (1).pdf")
				.getInputStream(), response.getOutputStream());
		response.flushBuffer();
	}

	@GetMapping("/replace")
	public String replaceFile() {

		Path sourceFilePath = Paths.get("C:\\Users\\ankit.kumarsingh\\Downloads\\Monthly AMRC  (1).pdf");
		Path targetFilePath = Paths.get("C:\\Users\\ankit.kumarsingh\\Desktop\\NewFile.pdf");

		try {
			Files.copy(sourceFilePath, targetFilePath, StandardCopyOption.REPLACE_EXISTING);
			Files.delete(sourceFilePath);

			return "replace.html";
		} catch (IOException e) {
			return "An error occurred" + e.getMessage();
		}
	}

	@GetMapping("/dash")
	public String dashboard() {

		return "dashboard.html";
	}

	@GetMapping("/logout")
	public String logout() {

		return "logout.html";
	}

}
